
import Image from "next/image";

export default function Home() {
  return (
    <div className="min-h-screen p-6 space-y-10">
      <header className="text-center space-y-4">
        <Image 
          src="/logo.png" 
          alt="Logo RenovCreuse" 
          width={150} 
          height={150} 
          className="mx-auto"
        />
        <h1 className="text-3xl font-bold text-green-800">RenovCreuse</h1>
        <p className="text-lg max-w-xl mx-auto">
          Entreprise de rénovation tous corps d’état dans toute la Creuse. Du sol au plafond, à l’intérieur comme à l’extérieur, nous redonnons vie à vos espaces.
        </p>
      </header>

      <section>
        <h2 className="text-xl font-semibold text-green-700">Nos prestations</h2>
        <ul className="list-disc pl-5">
          <li>Peinture intérieure & extérieure</li>
          <li>Menuiserie & agencement</li>
          <li>Isolation, plâtrerie (ratissage, plaques de plâtre)</li>
          <li>Électricité & plomberie</li>
          <li>Revêtements de sol : parquet, carrelage</li>
          <li>Terrasses & terrassement</li>
          <li>Ravalement de façades</li>
          <li>Rénovation générale</li>
        </ul>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-green-700">Zone d’intervention</h2>
        <p>Nous intervenons sur tout le département de la Creuse.</p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-green-700">Galerie</h2>
        <div className="grid grid-cols-2 gap-4">
          <Image src="/exemples/photo1.jpg" alt="chantier 1" width={300} height={200} />
          <Image src="/exemples/photo2.jpg" alt="chantier 2" width={300} height={200} />
          <Image src="/exemples/photo3.jpg" alt="chantier 3" width={300} height={200} />
          <Image src="/exemples/photo4.jpg" alt="chantier 4" width={300} height={200} />
        </div>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-green-700">Contact</h2>
        <p>Téléphone : <a href="tel:0768454564">07.68.45.45.64</a></p>
        <p>Email : <a href="mailto:Renovcreuse@gmail.com">Renovcreuse@gmail.com</a></p>
      </section>

      <section>
        <h2 className="text-xl font-semibold text-green-700">Formulaire de contact</h2>
        <form className="flex flex-col space-y-2 max-w-md">
          <input type="text" placeholder="Nom" className="border p-2" />
          <input type="email" placeholder="Email" className="border p-2" />
          <textarea placeholder="Votre message..." className="border p-2" rows={4}></textarea>
          <button type="submit" className="bg-green-700 text-white p-2 rounded hover:bg-green-800">
            Envoyer
          </button>
        </form>
      </section>
    </div>
  );
}
